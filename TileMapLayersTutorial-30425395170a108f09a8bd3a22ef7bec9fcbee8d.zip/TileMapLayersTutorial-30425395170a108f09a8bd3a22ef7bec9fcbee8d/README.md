This project shows the basics of working with TileMapLayers in Godot 4.3. 
(It's very similar to 4.2).

Goes with my tutorial video here: https://youtu.be/vEyDbROrw0Q
